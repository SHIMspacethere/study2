a=0
b=""
c=True

print("a", type(a))
print("b", type(b))
print("c", type(c))