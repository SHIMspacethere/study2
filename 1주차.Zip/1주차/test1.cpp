#include <iostream>

using namespace std;

void main() {
  int a = 5;
  int b = 5;
  
  cout << a+b << endl;
}
