a = input("What is a? >> ")
b = 5

print("a", type(a))
print("b", type(b))

print("a+b : ", a+b)
